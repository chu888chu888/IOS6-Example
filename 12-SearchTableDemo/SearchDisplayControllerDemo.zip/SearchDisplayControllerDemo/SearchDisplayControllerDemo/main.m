//
//  main.m
//  SearchDisplayControllerDemo
//
//  Created by Bob on 06/09/13.
//  Copyright (c) 2013 CocoaBob. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CBAppDelegate class]));
    }
}
