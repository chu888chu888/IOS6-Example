//
//  CBViewController.h
//  SearchDisplayControllerDemo
//
//  Created by Bob on 06/09/13.
//  Copyright (c) 2013 CocoaBob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CBViewController : UITableViewController

@end
